import React from "react";
import { Routes, Route, Navigate, Link, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

import Login from "./pages/Login";
import DealsKanban from "./pages/DealsKanban";
import DealDetail from "./pages/DealDetail";

import AccountsList from "./pages/AccountsList";
import AccountDetail from "./pages/AccountDetail";

import { api } from "./api";

type Me = { id: number; username: string };

async function me(): Promise<Me> {
  const { data } = await api.get("/auth/me/");
  return data;
}

function Protected({ children }: { children: React.ReactNode }) {
  const q = useQuery({ queryKey: ["me"], queryFn: me, retry: false });
  if (q.isLoading) return <div className="p-6">Carregando...</div>;
  if (q.isError) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function Topbar() {
  const nav = useNavigate();
  const meQ = useQuery({ queryKey: ["me"], queryFn: me, retry: false });

  async function handleLogout() {
    try {
      await api.post("/auth/logout/");
    } finally {
      // força re-check de auth
      await meQ.refetch();
      nav("/login");
    }
  }

  return (
    <div className="sticky top-0 z-40 border-b border-slate-800 bg-slate-950/70 backdrop-blur">
      <div className="px-6 py-3 flex items-center gap-4">
        <div className="font-extrabold">CRM</div>

        <Link to="/deals" className="text-sm opacity-80 hover:opacity-100 transition">
          Kanban
        </Link>

        <Link to="/accounts" className="text-sm opacity-80 hover:opacity-100 transition">
          Construtoras
        </Link>

        <div className="ml-auto flex items-center gap-3">
          {meQ.data ? (
            <div className="text-sm opacity-80">Olá, {meQ.data.username}</div>
          ) : null}

          <button
            onClick={handleLogout}
            className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm hover:bg-slate-800 transition"
          >
            Sair
          </button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen">
      <Routes>
        <Route path="/login" element={<Login />} />

        <Route
          path="/*"
          element={
            <Protected>
              <>
                <Topbar />
                <Routes>
                  <Route path="/" element={<Navigate to="/deals" replace />} />

                  <Route path="/deals" element={<DealsKanban />} />
                  <Route path="/deals/:id" element={<DealDetail />} />

                  <Route path="/accounts" element={<AccountsList />} />
                  <Route path="/accounts/:id" element={<AccountDetail />} />

                  <Route path="*" element={<div className="p-6">Página não encontrada.</div>} />
                </Routes>
              </>
            </Protected>
          }
        />
      </Routes>
    </div>
  );
}