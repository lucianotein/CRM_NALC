import React, { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createAccount, listAccounts } from "../crmApi";
import { Link } from "react-router-dom";

export default function AccountsList() {
  const qc = useQueryClient();
  const { data, isLoading, isError } = useQuery({
    queryKey: ["accounts"],
    queryFn: listAccounts,
  });

  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);

  const mut = useMutation({
    mutationFn: createAccount,
    onSuccess: async () => {
      setOpen(false);
      await qc.invalidateQueries({ queryKey: ["accounts"] });
    },
  });

  const filtered = useMemo(() => {
    const arr = data || [];
    const s = q.trim().toLowerCase();
    if (!s) return arr;
    return arr.filter(
      (a: any) =>
        (a.name || "").toLowerCase().includes(s) || (a.cnpj || "").includes(s)
    );
  }, [data, q]);

  if (isLoading) return <div className="p-6">Carregando...</div>;
  if (isError)
    return (
      <div className="p-6 text-red-400">Erro ao carregar.</div>
    );

  return (
    <div className="p-6">
      <div className="flex items-center gap-3 mb-4">
        <h1 className="text-xl font-bold m-0">Construtoras</h1>
        <button
          onClick={() => setOpen(true)}
          className="ml-auto rounded-lg bg-slate-100 text-slate-900 font-semibold px-3 py-2 hover:opacity-90 transition"
        >
          + Nova construtora
        </button>
      </div>

      <div className="mb-4">
        <input
          placeholder="Buscar por nome / CNPJ..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-3">
        {filtered.map((a: any) => (
          <Link
            key={a.id}
            to={`/accounts/${a.id}`}
            className="block rounded-2xl border border-slate-800 bg-slate-900/40 p-4 hover:border-slate-700 transition"
          >
            <div className="font-extrabold">{a.name}</div>
            <div className="text-xs opacity-80 mt-1">
              {a.cnpj ? `CNPJ: ${a.cnpj} • ` : ""}
              {a.city || "-"} / {a.state || "-"}
            </div>
          </Link>
        ))}

        {filtered.length === 0 && (
          <div className="opacity-70 text-sm">
            Nenhuma construtora cadastrada.
          </div>
        )}
      </div>

      {open && (
        <Modal title="Nova Construtora" onClose={() => setOpen(false)}>
          <AccountForm
            loading={mut.isPending}
            onSubmit={(payload) => mut.mutate(payload)}
          />
        </Modal>
      )}
    </div>
  );
}

function AccountForm({
  loading,
  onSubmit,
}: {
  loading: boolean;
  onSubmit: (payload: any) => void;
}) {
  const [name, setName] = useState("");
  const [cnpj, setCnpj] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("PR");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({ name, cnpj, city, state, is_active: true });
      }}
      className="grid gap-3"
    >
      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Nome</label>
        <input
          placeholder="Nome da construtora"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">CNPJ (opcional)</label>
        <input
          placeholder="CNPJ"
          value={cnpj}
          onChange={(e) => setCnpj(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_120px] gap-3">
        <div className="grid gap-1">
          <label className="text-xs text-slate-400">Cidade</label>
          <input
            placeholder="Cidade"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          />
        </div>

        <div className="grid gap-1">
          <label className="text-xs text-slate-400">UF</label>
          <input
            placeholder="UF"
            value={state}
            onChange={(e) => setState(e.target.value.toUpperCase())}
            maxLength={2}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          />
        </div>
      </div>

      <button
        disabled={loading}
        className="mt-1 w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 disabled:opacity-50 transition"
      >
        {loading ? "Salvando..." : "Salvar"}
      </button>
    </form>
  );
}

function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-black/60 grid place-items-center p-4 z-50"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-2xl"
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="font-extrabold">{title}</div>
          <button
            onClick={onClose}
            className="ml-auto rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm hover:bg-slate-800 transition"
          >
            Fechar
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}