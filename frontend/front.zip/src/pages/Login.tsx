import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, ensureCsrf } from "../api";

export default function Login() {
  const nav = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    try {
      await ensureCsrf();
      await api.post("/auth/login/", { username, password });
      nav("/deals");
    } catch {
      setError("Usuário ou senha inválidos");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl">
        <h1 className="text-3xl font-bold text-center mb-6">
          CRM - Login
        </h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-slate-600"
            placeholder="Usuário"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />

          <input
            type="password"
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-slate-600"
            placeholder="Senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          {error && (
            <div className="text-red-400 text-sm">{error}</div>
          )}

          <button
            className="w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 transition"
            type="submit"
          >
            Entrar
          </button>
        </form>

        <p className="text-xs text-slate-400 text-center mt-4">
          Use o mesmo usuário do Django Admin.
        </p>
      </div>
    </div>
  );
}