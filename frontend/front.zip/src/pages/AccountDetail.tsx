import React, { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  createContact,
  createProject,
  getAccount,
  listContacts,
  listProjects,
} from "../crmApi";

// ✅ Oportunidades (Kanban)
import { createDeal, listDeals } from "../dealsApi";
import type { DealStage } from "../types";

export default function AccountDetail() {
  const { id } = useParams();
  const accountId = Number(id);
  const qc = useQueryClient();

  const accQ = useQuery({
    queryKey: ["account", accountId],
    queryFn: () => getAccount(accountId),
    enabled: Number.isFinite(accountId),
  });

  const contactsQ = useQuery({ queryKey: ["contacts"], queryFn: listContacts });
  const projectsQ = useQuery({ queryKey: ["projects"], queryFn: listProjects });

  // ✅ lista global de deals e filtramos por account
  const dealsQ = useQuery({ queryKey: ["deals"], queryFn: listDeals });

  const contacts = useMemo(
    () => (contactsQ.data || []).filter((c: any) => c.account === accountId),
    [contactsQ.data, accountId]
  );

  const projects = useMemo(
    () => (projectsQ.data || []).filter((p: any) => p.account === accountId),
    [projectsQ.data, accountId]
  );

  const deals = useMemo(
    () => (dealsQ.data || []).filter((d: any) => d.account === accountId),
    [dealsQ.data, accountId]
  );

  const [openContact, setOpenContact] = useState(false);
  const [openProject, setOpenProject] = useState(false);
  const [openDeal, setOpenDeal] = useState(false);

  const mutContact = useMutation({
    mutationFn: createContact,
    onSuccess: async () => {
      setOpenContact(false);
      await qc.invalidateQueries({ queryKey: ["contacts"] });
    },
  });

  const mutProject = useMutation({
    mutationFn: createProject,
    onSuccess: async () => {
      setOpenProject(false);
      await qc.invalidateQueries({ queryKey: ["projects"] });
    },
  });

  // ✅ cria oportunidade vinculada à construtora
  const mutDeal = useMutation({
    mutationFn: createDeal,
    onSuccess: async () => {
      setOpenDeal(false);
      await qc.invalidateQueries({ queryKey: ["deals"] });
    },
  });

  if (accQ.isLoading) return <div className="p-6">Carregando...</div>;
  if (accQ.isError || !accQ.data)
    return <div className="p-6 text-red-400">Conta não encontrada.</div>;

  const a: any = accQ.data;

  return (
    <div className="p-6">
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4 mb-4">
        <div className="font-extrabold text-lg">{a.name}</div>
        <div className="text-xs opacity-80 mt-1">
          {a.cnpj ? `CNPJ: ${a.cnpj} • ` : ""}
          {a.city || "-"} / {a.state || "-"}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Contatos */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="font-extrabold">Contatos</div>
            <button
              onClick={() => setOpenContact(true)}
              className="ml-auto rounded-lg bg-slate-100 text-slate-900 font-semibold px-3 py-2 hover:opacity-90 transition"
            >
              + Novo contato
            </button>
          </div>

          <div className="grid gap-2">
            {contacts.map((c: any) => (
              <div
                key={c.id}
                className="rounded-xl border border-slate-800 bg-slate-950/60 p-3"
              >
                <div className="font-semibold">{c.name}</div>
                <div className="text-xs opacity-80 mt-1">
                  {c.role || "-"} • {c.phone || "-"} • {c.email || "-"}
                </div>
              </div>
            ))}
            {contacts.length === 0 && (
              <div className="opacity-70 text-sm">Nenhum contato cadastrado.</div>
            )}
          </div>
        </div>

        {/* Empreendimentos */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="font-extrabold">Empreendimentos</div>
            <button
              onClick={() => setOpenProject(true)}
              className="ml-auto rounded-lg bg-slate-100 text-slate-900 font-semibold px-3 py-2 hover:opacity-90 transition"
            >
              + Novo empreendimento
            </button>
          </div>

          <div className="grid gap-2">
            {projects.map((p: any) => (
              <div
                key={p.id}
                className="rounded-xl border border-slate-800 bg-slate-950/60 p-3"
              >
                <div className="font-semibold">{p.name}</div>
                <div className="text-xs opacity-80 mt-1">
                  Entrega obra: {p.obra_entrega_prevista || "-"} • {p.city || "-"} /{" "}
                  {p.state || "-"}
                </div>
              </div>
            ))}
            {projects.length === 0 && (
              <div className="opacity-70 text-sm">
                Nenhum empreendimento cadastrado.
              </div>
            )}
          </div>
        </div>

        {/* ✅ Oportunidades */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4 lg:col-span-2">
          <div className="flex items-center gap-3 mb-3">
            <div className="font-extrabold">Oportunidades</div>

            <button
              onClick={() => setOpenDeal(true)}
              className="ml-auto rounded-lg bg-slate-100 text-slate-900 font-semibold px-3 py-2 hover:opacity-90 transition"
            >
              + Nova oportunidade
            </button>
          </div>

          <div className="grid gap-2">
            {deals.map((d: any) => {
            const rawValue =
              d.valor_total ?? d.value ?? d.amount ?? d.valor ?? null;
            const numValue =
              rawValue === null || rawValue === undefined || rawValue === ""
                ? null
                : Number(rawValue);

            return (
              <Link
                key={d.id}
                to={`/deals/${d.id}`}
                className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 hover:bg-slate-950/80 transition block"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="font-semibold">{d.title}</div>
                  <div className="text-xs opacity-80">{d.stage || "-"}</div>
                </div>

                <div className="text-xs opacity-80 mt-1">
                  {numValue !== null && Number.isFinite(numValue)
                    ? `Valor: R$ ${numValue.toLocaleString("pt-BR")}`
                    : "Valor: -"}
                </div>
              </Link>
            );
          })}

            {deals.length === 0 && (
              <div className="opacity-70 text-sm">
                Nenhuma oportunidade cadastrada.
              </div>
            )}
          </div>
        </div>
      </div>

      {openContact && (
        <Modal title="Novo Contato" onClose={() => setOpenContact(false)}>
          <ContactForm
            loading={mutContact.isPending}
            onSubmit={(payload: any) =>
              mutContact.mutate({ ...payload, account: accountId })
            }
          />
        </Modal>
      )}

      {openProject && (
        <Modal title="Novo Empreendimento" onClose={() => setOpenProject(false)}>
          <ProjectForm
            loading={mutProject.isPending}
            onSubmit={(payload: any) =>
              mutProject.mutate({ ...payload, account: accountId })
            }
          />
        </Modal>
      )}

      {openDeal && (
        <Modal title="Nova Oportunidade" onClose={() => setOpenDeal(false)}>
          <DealForm
            loading={mutDeal.isPending}
            onSubmit={(payload: any) =>
              mutDeal.mutate({
                ...payload,
                account: accountId,
                stage: "LEAD" as DealStage,
              })
            }
          />
        </Modal>
      )}
    </div>
  );
}

function ContactForm({
  loading,
  onSubmit,
}: {
  loading: boolean;
  onSubmit: (payload: any) => void;
}) {
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({ name, role, phone, email, is_primary: false });
      }}
      className="grid gap-3"
    >
      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Nome</label>
        <input
          placeholder="Nome"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Cargo / Função</label>
        <input
          placeholder="Cargo / Função"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Telefone</label>
        <input
          placeholder="Telefone"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Email</label>
        <input
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <button
        disabled={loading}
        className="mt-1 w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 disabled:opacity-50 transition"
      >
        {loading ? "Salvando..." : "Salvar"}
      </button>
    </form>
  );
}

function ProjectForm({
  loading,
  onSubmit,
}: {
  loading: boolean;
  onSubmit: (payload: any) => void;
}) {
  const [name, setName] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("PR");
  const [obra, setObra] = useState("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({
          name,
          city,
          state,
          obra_entrega_prevista: obra || null,
          notes: "",
        });
      }}
      className="grid gap-3"
    >
      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Nome do empreendimento</label>
        <input
          placeholder="Nome do empreendimento"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_120px] gap-3">
        <div className="grid gap-1">
          <label className="text-xs text-slate-400">Cidade</label>
          <input
            placeholder="Cidade"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          />
        </div>

        <div className="grid gap-1">
          <label className="text-xs text-slate-400">UF</label>
          <input
            placeholder="UF"
            value={state}
            onChange={(e) => setState(e.target.value.toUpperCase())}
            maxLength={2}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          />
        </div>
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">
          Entrega obra (YYYY-MM-DD)
        </label>
        <input
          placeholder="Entrega obra (YYYY-MM-DD)"
          value={obra}
          onChange={(e) => setObra(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <button
        disabled={loading}
        className="mt-1 w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 disabled:opacity-50 transition"
      >
        {loading ? "Salvando..." : "Salvar"}
      </button>
    </form>
  );
}

function DealForm({
  loading,
  onSubmit,
}: {
  loading: boolean;
  onSubmit: (payload: any) => void;
}) {
  const [title, setTitle] = useState("");
  const [value, setValue] = useState<string>("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({
          title,
          value: value ? Number(value) : null,
        });
      }}
      className="grid gap-3"
    >
      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Título</label>
        <input
          placeholder="Ex: Big Tower - 2 elevadores"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Valor (opcional)</label>
        <input
          placeholder="Ex: 180000"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          inputMode="numeric"
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <button
        disabled={loading}
        className="mt-1 w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 disabled:opacity-50 transition"
      >
        {loading ? "Salvando..." : "Salvar"}
      </button>
    </form>
  );
}

function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-black/60 grid place-items-center p-4 z-50"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-2xl"
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="font-extrabold">{title}</div>
          <button
            onClick={onClose}
            className="ml-auto rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm hover:bg-slate-800 transition"
          >
            Fechar
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}