// frontend/src/pages/DealsKanban.tsx
import React, { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { Deal, DealStage } from "../types";
import { listDeals, updateDealStage } from "../dealsApi";
import { createDeal, listAccounts, type Account } from "../crmApi";
import { Link } from "react-router-dom";

const COLUMNS: { key: DealStage; title: string }[] = [
  { key: "LEAD", title: "Lead" },
  { key: "CONTATO", title: "Contato" },
  { key: "PROPOSTA", title: "Proposta" },
  { key: "NEGOCIACAO", title: "Negociação" },
  { key: "FECHADO_GANHO", title: "Fechado" },
];

// se o seu model usa outro nome, troque aqui (ex: "valor", "amount", "total")
type DealWithExtras = Deal & {
  account_name?: string;
  project_name?: string | null;
  valor_total?: string | number | null;
};

function formatBRL(v: unknown) {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : Number(String(v).replace(",", "."));
  if (!Number.isFinite(n)) return null;
  return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default function DealsKanban() {
  const qc = useQueryClient();

  const dealsQ = useQuery({ queryKey: ["deals"], queryFn: listDeals });
  const accountsQ = useQuery({ queryKey: ["accounts"], queryFn: listAccounts });

  const [draggingId, setDraggingId] = useState<number | null>(null);
  const [openNew, setOpenNew] = useState(false);

  const updateStageMut = useMutation({
    mutationFn: ({ id, stage }: { id: number; stage: DealStage }) =>
      updateDealStage(id, stage),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["deals"] }),
  });

  const createDealMut = useMutation({
    mutationFn: createDeal,
    onSuccess: async () => {
      setOpenNew(false);
      await qc.invalidateQueries({ queryKey: ["deals"] });
    },
  });

  const grouped = useMemo(() => {
    const g: Record<string, DealWithExtras[]> = {};
    for (const c of COLUMNS) g[c.key] = [];
    (dealsQ.data || []).forEach((d: any) => {
      const k = d.stage as DealStage;
      if (!g[k]) g[k] = [];
      g[k].push(d);
    });
    return g as Record<DealStage, DealWithExtras[]>;
  }, [dealsQ.data]);

  function onDrop(stage: DealStage) {
    if (!draggingId) return;
    updateStageMut.mutate({ id: draggingId, stage });
    setDraggingId(null);
  }

  if (dealsQ.isLoading) return <div className="p-6">Carregando deals...</div>;
  if (dealsQ.isError)
    return <div className="p-6 text-red-400">Erro ao carregar deals</div>;

  const accounts = accountsQ.data || [];

  return (
    <div className="p-6">
      <div className="flex items-center gap-3 mb-4">
        <h1 className="text-xl font-bold m-0">Kanban</h1>

        <button
          onClick={() => setOpenNew(true)}
          className="ml-auto rounded-lg bg-slate-100 text-slate-900 font-semibold px-3 py-2 hover:opacity-90 transition"
        >
          + Nova oportunidade
        </button>
      </div>

      {(updateStageMut.isPending || createDealMut.isPending) && (
        <div className="mb-3 text-sm opacity-80">
          {updateStageMut.isPending
            ? "Atualizando etapa..."
            : "Criando oportunidade..."}
        </div>
      )}

      <div
        className="grid gap-3 items-start"
        style={{
          gridTemplateColumns: `repeat(${COLUMNS.length}, minmax(240px, 1fr))`,
        }}
      >
        {COLUMNS.map((col) => (
          <div
            key={col.key}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => onDrop(col.key)}
            className="rounded-2xl border border-slate-800 bg-slate-900/40 p-3 min-h-[520px]"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="font-extrabold">
                {col.title}{" "}
                <span className="opacity-70">
                  ({(grouped[col.key] || []).length})
                </span>
              </div>
            </div>

            <div className="grid gap-2">
              {(grouped[col.key] || []).map((deal) => (
                <DealCard
                  key={deal.id}
                  deal={deal}
                  onDragStart={() => setDraggingId(deal.id)}
                  onChangeStage={(stage) =>
                    updateStageMut.mutate({ id: deal.id, stage })
                  }
                />
              ))}
            </div>

            {(grouped[col.key] || []).length === 0 && (
              <div className="opacity-60 text-xs mt-2">
                Sem oportunidades aqui.
              </div>
            )}
          </div>
        ))}
      </div>

      {openNew && (
        <Modal title="Nova Oportunidade" onClose={() => setOpenNew(false)}>
          <NewDealForm
            accounts={accounts}
            loading={createDealMut.isPending}
            onSubmit={(payload: {
              title: string;
              account: number;
              valor_total?: number | null;
            }) => createDealMut.mutate({ ...payload, stage: "LEAD" } as any)}
          />
        </Modal>
      )}
    </div>
  );
}

function DealCard({
  deal,
  onDragStart,
  onChangeStage,
}: {
  deal: DealWithExtras;
  onDragStart: () => void;
  onChangeStage: (stage: DealStage) => void;
}) {
  const brl = formatBRL(deal.valor_total);

  return (
    <div
      draggable
      onDragStart={onDragStart}
      className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 hover:border-slate-700 transition"
    >
      <div className="flex items-start justify-between gap-2">
        {/* ✅ TÍTULO VIRANDO LINK PARA DETALHE */}
        <Link
          to={`/deals/${deal.id}`}
          className="font-extrabold leading-tight hover:underline"
          onClick={(e) => e.stopPropagation()}
          title="Abrir detalhes"
        >
          {deal.title}
        </Link>

        <span className="text-[11px] px-2 py-1 rounded-full bg-slate-800/70 border border-slate-700">
          {deal.stage}
        </span>
      </div>

      <div className="text-xs opacity-85 mt-2">
        Construtora: {deal.account_name || `#${deal.account}`}
      </div>

      {deal.project && (
        <div className="text-xs opacity-70 mt-1">
          Obra: {deal.project_name || `#${deal.project}`}
        </div>
      )}

      {brl && (
        <div className="mt-2 text-sm font-semibold">
          Valor: <span className="text-slate-100">{brl}</span>
        </div>
      )}

      <div className="text-xs opacity-80 mt-2">
        Último contato:{" "}
        {deal.last_contact_at
          ? new Date(deal.last_contact_at).toLocaleString("pt-BR")
          : "-"}
      </div>

      <div className="mt-3">
        <select
          value={deal.stage}
          onChange={(e) => onChangeStage(e.target.value as DealStage)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-600"
        >
          <option value="LEAD">Lead</option>
          <option value="CONTATO">Contato</option>
          <option value="PROPOSTA">Proposta</option>
          <option value="NEGOCIACAO">Negociação</option>
          <option value="FECHADO_GANHO">Fechado</option>
          <option value="PERDIDO">Perdido</option>
          <option value="PAUSADO">Pausado</option>
        </select>
      </div>
    </div>
  );
}

function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-black/60 grid place-items-center p-4 z-50"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-2xl"
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="font-extrabold">{title}</div>
          <button
            onClick={onClose}
            className="ml-auto rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm hover:bg-slate-800 transition"
          >
            Fechar
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function NewDealForm({
  accounts,
  loading,
  onSubmit,
}: {
  accounts: Account[];
  loading: boolean;
  onSubmit: (payload: {
    title: string;
    account: number;
    valor_total?: number | null;
  }) => void;
}) {
  const [title, setTitle] = useState("");
  const [account, setAccount] = useState<number>(accounts?.[0]?.id || 0);
  const [valor, setValor] = useState<string>("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const v = valor.trim() ? Number(valor.replace(",", ".")) : null;
        onSubmit({
          title,
          account,
          valor_total: Number.isFinite(v as number) ? (v as number) : null,
        });
      }}
      className="grid gap-3"
    >
      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Título</label>
        <input
          placeholder="Ex: Elevador - Edifício Solar"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Construtora</label>
        <select
          value={account}
          onChange={(e) => setAccount(Number(e.target.value))}
          required
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        >
          <option value={0} disabled>
            Selecione a construtora...
          </option>
          {accounts.map((a) => (
            <option key={a.id} value={a.id}>
              {a.name}
            </option>
          ))}
        </select>
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Valor (opcional)</label>
        <input
          placeholder="Ex: 250000"
          value={valor}
          onChange={(e) => setValor(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
        <div className="text-[11px] text-slate-500">
          Dica: digite só números (ex: 250000) ou com vírgula (ex:
          250000,50).
        </div>
      </div>

      <button
        disabled={loading || account === 0}
        className="mt-1 w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 disabled:opacity-50 transition"
      >
        {loading ? "Criando..." : "Criar Oportunidade"}
      </button>
    </form>
  );
}