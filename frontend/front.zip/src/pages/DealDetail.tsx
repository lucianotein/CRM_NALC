import React, { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { Deal, DealStage } from "../types";
import { api } from "../api";
import { updateDealStage } from "../dealsApi";

import {
  createActivity,
  listActivities,
  type Activity,
  type ActivityType,
} from "../activitiesApi";

import {
  listAttachments,
  uploadAttachment,
  type DealAttachment,
  type AttachmentType,
} from "../attachmentsApi";

import {
  listProposals,
  createProposal,
  type Proposal,
  type ProposalStatus,
} from "../proposalsApi";

// ✅ usa listProjects do seu crmApi (ajuste o caminho se necessário)
import { listProjects } from "../crmApi";

/** ===========================
 * Types
 * =========================== */

type DealWithExtras = Deal & {
  account_name?: string;
  project_name?: string | null;
  valor_total?: string | number | null;
};

type ProjectItem = {
  id: number;
  account: number;
  name: string;
  city?: string | null;
  state?: string | null;
  obra_entrega_prevista?: string | null;
};

/** ===========================
 * Helpers
 * =========================== */

function formatBRL(v: unknown) {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : Number(String(v).replace(",", "."));
  if (!Number.isFinite(n)) return null;
  return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function fmtDT(s?: string | null) {
  if (!s) return "-";
  try {
    return new Date(s).toLocaleString("pt-BR");
  } catch {
    return s;
  }
}

function fmtDate(s?: string | null) {
  if (!s) return "-";
  try {
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s; // já vem YYYY-MM-DD
    return new Date(s).toLocaleDateString("pt-BR");
  } catch {
    return s;
  }
}

function attachmentUrl(a: any) {
  return a?.file_url || a?.file;
}

function pickLatestAttachment(items: any[]) {
  if (!items || items.length === 0) return null;
  return [...items].sort(
    (x, y) => new Date(y.created_at).getTime() - new Date(x.created_at).getTime()
  )[0];
}

function parseMoneyToNumberOrNull(s: string) {
  const t = (s || "").trim();
  if (!t) return null;
  const n = Number(t.replace(/\./g, "").replace(",", "."));
  if (!Number.isFinite(n)) return null;
  return n;
}

function toIsoFromLocalDT(local: string): string | null {
  const t = (local || "").trim();
  if (!t) return null;

  // "YYYY-MM-DDTHH:mm"
  const [datePart, timePart] = t.split("T");
  if (!datePart || !timePart) return null;

  const [y, m, d] = datePart.split("-").map(Number);
  const [hh, mm] = timePart.split(":").map(Number);

  const dt = new Date(y, (m || 1) - 1, d || 1, hh || 0, mm || 0, 0, 0);
  if (Number.isNaN(dt.getTime())) return null;

  return dt.toISOString();
}

function nowLocalDT(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours()
  )}:${pad(d.getMinutes())}`;
}

async function getDeal(id: number): Promise<DealWithExtras> {
  const { data } = await api.get(`/deals/${id}/`);
  return data;
}

/** ===========================
 * Labels
 * =========================== */

const TYPE_LABEL: Record<string, string> = {
  VISITA: "Visita",
  LIGACAO: "Ligação",
  WHATSAPP: "WhatsApp",
  REUNIAO: "Reunião",
  EMAIL: "E-mail",
  TAREFA: "Tarefa",
};

const ATT_TYPE_LABEL: Record<AttachmentType, string> = {
  PROPOSTA: "Proposta",
  CONTRATO: "Contrato",
  MEMORIAL: "Memorial",
  OUTRO: "Outro",
};

const PROPOSAL_STATUS_LABEL: Record<ProposalStatus, string> = {
  DRAFT: "Rascunho",
  SENT: "Enviada",
  ACCEPTED: "Aceita",
  REJECTED: "Recusada",
};

function StagePill({ stage }: { stage: DealStage }) {
  return (
    <span className="text-[11px] px-2 py-1 rounded-full bg-slate-800/70 border border-slate-700">
      {stage}
    </span>
  );
}

function StatusPill({ status }: { status: string }) {
  const base =
    "text-[11px] px-2 py-1 rounded-full border inline-flex items-center gap-1";
  if (status === "PENDING")
    return (
      <span className={`${base} bg-amber-900/30 border-amber-800`}>
        PENDENTE
      </span>
    );
  if (status === "DONE")
    return (
      <span className={`${base} bg-emerald-900/20 border-emerald-800`}>
        FEITO
      </span>
    );
  if (status === "CANCELED")
    return (
      <span className={`${base} bg-slate-900/40 border-slate-700`}>
        CANCELADO
      </span>
    );
  return (
    <span className={`${base} bg-slate-900/40 border-slate-700`}>{status}</span>
  );
}

/** ===========================
 * Page
 * =========================== */

export default function DealDetail() {
  const { id } = useParams();
  const dealId = Number(id);
  const qc = useQueryClient();

  const dealQ = useQuery({
    queryKey: ["deal", dealId],
    queryFn: () => getDeal(dealId),
    enabled: Number.isFinite(dealId),
  });

  const actsQ = useQuery({
    queryKey: ["activities", dealId],
    queryFn: () => listActivities(dealId),
    enabled: Number.isFinite(dealId),
  });

  const attsQ = useQuery({
    queryKey: ["attachments", dealId],
    queryFn: () => listAttachments(dealId),
    enabled: Number.isFinite(dealId),
  });

  const propsQ = useQuery({
    queryKey: ["proposals", dealId],
    queryFn: () => listProposals(dealId),
    enabled: Number.isFinite(dealId),
  });

  const projectsQ = useQuery({
    queryKey: ["projects"],
    queryFn: listProjects,
  });

  const updateStageMut = useMutation({
    mutationFn: ({ stage }: { stage: DealStage }) => updateDealStage(dealId, stage),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ["deal", dealId] });
      await qc.invalidateQueries({ queryKey: ["deals"] });
    },
  });

  const [openAct, setOpenAct] = useState(false);
  const [openUpload, setOpenUpload] = useState(false);
  const [openProposal, setOpenProposal] = useState(false);
  const [openReschedule, setOpenReschedule] = useState(false);
  const [rescheduleAct, setRescheduleAct] = useState<any | null>(null);

  const createActMut = useMutation({
    mutationFn: createActivity,
    onSuccess: async () => {
      setOpenAct(false);
      await qc.invalidateQueries({ queryKey: ["activities", dealId] });
      await qc.invalidateQueries({ queryKey: ["deal", dealId] });
      await qc.invalidateQueries({ queryKey: ["deals"] });
    },
  });

  const uploadMut = useMutation({
    mutationFn: uploadAttachment,
    onSuccess: async () => {
      setOpenUpload(false);
      await qc.invalidateQueries({ queryKey: ["attachments", dealId] });
    },
  });

  const rescheduleMut = useMutation({
    mutationFn: async (input: {
      activityId: number;
      scheduled_for: string; // ISO
      note: string;
    }) => {
      const { data } = await api.post(`/activities/${input.activityId}/reschedule/`, {
        scheduled_for: input.scheduled_for,
        note: input.note,
      });
      return data;
    },
    onSuccess: async (updated) => {
      // ✅ atualiza cache na hora
      qc.setQueryData(["activities", dealId], (old: any) => {
        const arr = (old || []) as any[];
        return arr.map((a) => (a.id === updated.id ? { ...a, ...updated } : a));
      });

      setOpenReschedule(false);
      setRescheduleAct(null);

      await qc.invalidateQueries({ queryKey: ["activities", dealId] });
      await qc.invalidateQueries({ queryKey: ["deal", dealId] });
      await qc.invalidateQueries({ queryKey: ["deals"] });
    },
  });

  const createProposalMut = useMutation({
    mutationFn: async (input: {
      proposal: Partial<Proposal> & { deal: number };
      file?: File | null;
    }) => {
      const created = await createProposal(input.proposal);

      if (input.file) {
        await uploadAttachment({
          deal: input.proposal.deal,
          type: "PROPOSTA",
          version_label: created.version_label || "",
          file: input.file,
        });
      }

      return created;
    },
    onSuccess: async () => {
      setOpenProposal(false);
      await qc.invalidateQueries({ queryKey: ["proposals", dealId] });
      await qc.invalidateQueries({ queryKey: ["attachments", dealId] });
      await qc.invalidateQueries({ queryKey: ["deal", dealId] });
      await qc.invalidateQueries({ queryKey: ["deals"] });
    },
  });

  // ✅ mutation pra concluir / reabrir atividade
  const markDoneMut = useMutation({
    mutationFn: async (activityId: number) => {
      const { data } = await api.post(`/activities/${activityId}/mark-done/`);
      return data; // deve vir com status DONE
    },
    onSuccess: async (updated) => {
      // ✅ 1) atualiza imediatamente o cache da lista (UI muda na hora)
      qc.setQueryData(["activities", dealId], (old: any) => {
        const arr = (old || []) as any[];
        return arr.map((a) => (a.id === updated.id ? { ...a, ...updated } : a));
      });

      // ✅ 2) depois refaz o fetch (garante consistência)
      await qc.invalidateQueries({ queryKey: ["activities", dealId] });
      await qc.invalidateQueries({ queryKey: ["deal", dealId] });
      await qc.invalidateQueries({ queryKey: ["deals"] });
    },
  });

  const markPendingMut = useMutation({
    mutationFn: async (activityId: number) => {
      const { data } = await api.post(`/activities/${activityId}/mark-pending/`);
      return data;
    },
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ["activities", dealId] });
      await qc.invalidateQueries({ queryKey: ["deal", dealId] });
      await qc.invalidateQueries({ queryKey: ["deals"] });
    },
  });

  const activities = useMemo(() => {
    const arr = (actsQ.data || []) as any[];
    // ✅ ordena: pendentes por scheduled_for (mais próximo primeiro), depois concluidas por occurred_at/created_at
    return [...arr].sort((a, b) => {
      const aPending = a.status === "PENDING" && a.scheduled_for;
      const bPending = b.status === "PENDING" && b.scheduled_for;

      if (aPending && bPending) {
        return new Date(a.scheduled_for).getTime() - new Date(b.scheduled_for).getTime();
      }
      if (aPending && !bPending) return -1;
      if (!aPending && bPending) return 1;

      const da = new Date(a.occurred_at || a.created_at).getTime();
      const db = new Date(b.occurred_at || b.created_at).getTime();
      return db - da;
    });
  }, [actsQ.data]);

  const attachments = useMemo(() => {
    const arr = attsQ.data || [];
    return [...arr].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }, [attsQ.data]);

  const proposalAttachmentByVersion = useMemo(() => {
    const map = new Map<string, any>();
    const proposalAtts = (attachments || []).filter((a: any) => a.type === "PROPOSTA");

    const groups: Record<string, any[]> = {};
    for (const a of proposalAtts) {
      const key = (a.version_label || "").trim();
      if (!groups[key]) groups[key] = [];
      groups[key].push(a);
    }

    for (const key of Object.keys(groups)) {
      map.set(key, pickLatestAttachment(groups[key]));
    }

    return map;
  }, [attachments]);

  const proposals = useMemo(() => {
    const arr = propsQ.data || [];
    return [...arr].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }, [propsQ.data]);

  const accountIdForProjects = (dealQ.data as any)?.account ?? null;

  const accountProjects = useMemo(() => {
    const all = (projectsQ.data || []) as ProjectItem[];
    if (!accountIdForProjects) return [];
    return all.filter((p) => p.account === accountIdForProjects);
  }, [projectsQ.data, accountIdForProjects]);

  const projectNameById = useMemo(() => {
    const m = new Map<number, string>();
    accountProjects.forEach((p) => m.set(p.id, p.name));
    return m;
  }, [accountProjects]);

  function renderProposalProjects(p: Proposal) {
    const ids = (p as any).projects as number[] | undefined;
    if (!ids || ids.length === 0) return "-";

    const names = ids
      .map((id) => projectNameById.get(id) || `#${id}`)
      .join(", ");

    return names || "-";
  }

  if (dealQ.isLoading) return <div className="p-6">Carregando...</div>;
  if (dealQ.isError || !dealQ.data)
    return <div className="p-6 text-red-400">Oportunidade não encontrada.</div>;

  const d = dealQ.data;
  const valor = formatBRL((d as any).valor_total);

  return (
    <div className="p-6">
      <div className="flex items-center gap-3 mb-4">
        <Link
          to="/deals"
          className="text-sm opacity-80 hover:opacity-100 transition underline"
        >
          ← Voltar ao Kanban
        </Link>

        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => setOpenUpload(true)}
            className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm hover:bg-slate-800 transition"
          >
            + Anexar arquivo
          </button>

          <button
            onClick={() => setOpenProposal(true)}
            className="rounded-lg bg-slate-100 text-slate-900 font-semibold px-3 py-2 hover:opacity-90 transition"
          >
            + Registrar proposta
          </button>

          <button
            onClick={() => setOpenAct(true)}
            className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm hover:bg-slate-800 transition"
          >
            + Registrar atividade
          </button>
        </div>
      </div>

      {/* Cabeçalho */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4 mb-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-start gap-2">
              <div className="text-lg font-extrabold">{d.title}</div>
              <StagePill stage={d.stage} />
            </div>

            <div className="text-xs opacity-80 mt-1">
              Construtora:{" "}
              <span className="font-semibold">
                {(d as any).account_name || `#${(d as any).account}`}
              </span>
              {(d as any).project ? (
                <> • Obra: {(d as any).project_name || `#${(d as any).project}`}</>
              ) : null}
            </div>

            <div className="text-xs opacity-80 mt-2">
              Último contato: {(d as any).last_contact_at ? fmtDT((d as any).last_contact_at) : "-"}
              {valor ? (
                <>
                  {" "}
                  • Valor: <span className="font-semibold">{valor}</span>
                </>
              ) : null}
            </div>
          </div>

          <div className="min-w-[220px]">
            <label className="text-xs text-slate-400">Etapa</label>
            <select
              value={d.stage}
              onChange={(e) =>
                updateStageMut.mutate({ stage: e.target.value as DealStage })
              }
              className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-600"
            >
              <option value="LEAD">Lead</option>
              <option value="CONTATO">Contato</option>
              <option value="PROPOSTA">Proposta</option>
              <option value="NEGOCIACAO">Negociação</option>
              <option value="FECHADO_GANHO">Fechado</option>
              <option value="PERDIDO">Perdido</option>
              <option value="PAUSADO">Pausado</option>
            </select>

            {(updateStageMut.isPending ||
              createActMut.isPending ||
              uploadMut.isPending ||
              createProposalMut.isPending ||
              markDoneMut.isPending ||
              markPendingMut.isPending) && (
              <div className="text-xs opacity-70 mt-2">
                {updateStageMut.isPending
                  ? "Atualizando etapa..."
                  : createActMut.isPending
                  ? "Salvando atividade..."
                  : uploadMut.isPending
                  ? "Enviando arquivo..."
                  : createProposalMut.isPending
                  ? "Registrando proposta..."
                  : markDoneMut.isPending
                  ? "Concluindo..."
                  : "Reabrindo..."}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Propostas */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4 mb-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="font-extrabold">Propostas</div>
          <div className="text-xs opacity-70">({proposals.length})</div>
        </div>

        {propsQ.isLoading && (
          <div className="text-sm opacity-80">Carregando propostas...</div>
        )}
        {propsQ.isError && (
          <div className="text-sm text-red-400">Erro ao carregar propostas.</div>
        )}

        <div className="grid gap-2">
          {proposals.map((p) => (
            <div
              key={p.id}
              className="rounded-xl border border-slate-800 bg-slate-950/60 p-3"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">
                    Proposta{" "}
                    {p.version_label ? (
                      <span className="text-xs opacity-70">• {p.version_label}</span>
                    ) : null}
                  </div>
                  <div className="text-xs opacity-70 mt-1">
                    Empreendimentos:{" "}
                    <span className="font-semibold">{renderProposalProjects(p)}</span>
                  </div>

                  <div className="text-xs opacity-70 mt-1">
                    Status:{" "}
                    <span className="font-semibold">
                      {PROPOSAL_STATUS_LABEL[p.status]}
                    </span>
                    {" • "}Criada em: {fmtDT(p.created_at)}
                  </div>

                  <div className="text-xs opacity-70 mt-2">
                    Valor total:{" "}
                    <span className="font-semibold">{formatBRL(p.valor_total) || "-"}</span>
                    {" • "}Entrada:{" "}
                    <span className="font-semibold">{formatBRL(p.valor_entrada) || "-"}</span>
                  </div>

                  <div className="text-xs opacity-70 mt-1">
                    Permuta:{" "}
                    <span className="font-semibold">
                      {p.tem_permuta ? `Sim (${p.permuta_tipo || "-"})` : "Não"}
                    </span>
                    {p.tem_permuta ? (
                      <>
                        {" • "}Valor permuta:{" "}
                        <span className="font-semibold">{formatBRL((p as any).valor_permuta) || "-"}</span>
                      </>
                    ) : null}
                  </div>

                  <div className="text-xs opacity-70 mt-1">
                    Entrega obra:{" "}
                    <span className="font-semibold">{fmtDate((p as any).obra_entrega_prevista)}</span>
                    {" • "}Entrega elevadores:{" "}
                    <span className="font-semibold">{fmtDate((p as any).elevador_entrega_prevista)}</span>
                  </div>

                  {(p as any).notes ? (
                    <div className="text-sm mt-2 whitespace-pre-wrap opacity-90">
                      {(p as any).notes}
                    </div>
                  ) : null}
                </div>

                <div className="text-right flex flex-col items-end gap-2">
                  <div className="text-[11px] opacity-70">ID #{p.id}</div>

                  {(() => {
                    const key = (p.version_label || "").trim();
                    const att = proposalAttachmentByVersion.get(key);

                    if (!att) return null;

                    const url = attachmentUrl(att);
                    if (!url) return null;

                    return (
                      <div className="flex gap-2">
                        <a
                          href={url}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded-lg bg-slate-100 text-slate-900 font-semibold px-3 py-2 text-sm hover:opacity-90 transition"
                        >
                          Abrir arquivo
                        </a>

                        <a
                          href={url}
                          download
                          className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm hover:bg-slate-800 transition"
                        >
                          Baixar
                        </a>
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>
          ))}

          {proposals.length === 0 && !propsQ.isLoading && (
            <div className="text-sm opacity-70">
              Nenhuma proposta registrada ainda. Clique em <b>“Registrar proposta”</b>.
            </div>
          )}
        </div>
      </div>

      {/* Anexos */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4 mb-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="font-extrabold">Arquivos</div>
          <div className="text-xs opacity-70">({attachments.length})</div>
        </div>

        {attsQ.isLoading && (
          <div className="text-sm opacity-80">Carregando anexos...</div>
        )}
        {attsQ.isError && (
          <div className="text-sm text-red-400">Erro ao carregar anexos.</div>
        )}

        <div className="grid gap-2">
          {attachments.map((a) => (
            <div
              key={a.id}
              className="rounded-xl border border-slate-800 bg-slate-950/60 p-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-semibold">
                    {ATT_TYPE_LABEL[a.type] || a.type}
                    {a.version_label ? (
                      <span className="text-xs opacity-70"> • {a.version_label}</span>
                    ) : null}
                  </div>
                  <div className="text-xs opacity-70 mt-1">
                    Enviado em: {fmtDT((a as any).created_at)}
                  </div>
                </div>

                <a
                  className="text-sm underline opacity-90 hover:opacity-100"
                  href={(a as any).file_url || (a as any).file}
                  target="_blank"
                  rel="noreferrer"
                >
                  Abrir
                </a>
              </div>
            </div>
          ))}

          {attachments.length === 0 && !attsQ.isLoading && (
            <div className="text-sm opacity-70">
              Nenhum arquivo anexado ainda. Clique em <b>“Anexar arquivo”</b>.
            </div>
          )}
        </div>
      </div>

      {/* Timeline */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="font-extrabold">Atividades</div>
          <div className="text-xs opacity-70">({activities.length})</div>
        </div>

        {actsQ.isLoading && (
          <div className="text-sm opacity-80">Carregando atividades...</div>
        )}
        {actsQ.isError && (
          <div className="text-sm text-red-400">Erro ao carregar atividades.</div>
        )}

        <div className="grid gap-2">
          {activities.map((a: any) => {
            const isPending = a.status === "PENDING";
            const whenLabel = isPending ? "Agendado para" : "Aconteceu";
            const whenValue = isPending ? fmtDT(a.scheduled_for) : fmtDT(a.occurred_at);

            return (
              <div
                key={a.id}
                className="rounded-xl border border-slate-800 bg-slate-950/60 p-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="font-semibold">
                    {(TYPE_LABEL as any)[a.type] || a.type}{" "}
                    <span className="text-xs opacity-70">
                      • {whenLabel}: {whenValue}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <StatusPill status={a.status} />

                    {isPending ? (
                      <button
                        onClick={() => markDoneMut.mutate(a.id)}
                        className="rounded-lg bg-slate-100 text-slate-900 font-semibold px-3 py-1.5 text-sm hover:opacity-90 transition"
                      >
                        Concluir
                      </button>
                    ) : a.status === "DONE" ? (
                      <button
                        onClick={() => {
                          setRescheduleAct(a);
                          setOpenReschedule(true);
                        }}
                        className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-sm hover:bg-slate-800 transition"
                      >
                        Reabrir
                      </button>
                    ) : null}
                  </div>
                </div>

                {a.result ? (
                  <div className="text-sm mt-2">
                    <span className="opacity-70">Resultado:</span> {a.result}
                  </div>
                ) : null}

                {a.notes ? (
                  <div className="text-sm mt-1 whitespace-pre-wrap opacity-90">
                    {a.notes}
                  </div>
                ) : null}

                <div className="text-[11px] opacity-60 mt-2">
                  Registrado no CRM: {fmtDT(a.created_at)}
                </div>
              </div>
            );
          })}

          {activities.length === 0 && !actsQ.isLoading && (
            <div className="text-sm opacity-70">
              Nenhuma atividade registrada ainda. Clique em <b>“Registrar atividade”</b>.
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {openAct && (
        <Modal title="Registrar atividade" onClose={() => setOpenAct(false)}>
          <ActivityForm
            loading={createActMut.isPending}
            onSubmit={(payload) => createActMut.mutate({ ...payload, deal: dealId })}
          />
        </Modal>
      )}

      {openUpload && (
        <Modal title="Anexar arquivo" onClose={() => setOpenUpload(false)}>
          <UploadForm
            loading={uploadMut.isPending}
            onSubmit={(payload) => uploadMut.mutate({ ...payload, deal: dealId })}
          />
        </Modal>
      )}

      {openProposal && (
        <Modal title="Registrar proposta" onClose={() => setOpenProposal(false)}>
          <ProposalForm
            loading={createProposalMut.isPending}
            projects={accountProjects.map((p) => ({ id: p.id, name: p.name }))}
            onSubmit={(payload) =>
              createProposalMut.mutate({
                proposal: { ...payload, deal: dealId },
                file: (payload as any)._file || null,
              })
            }
          />
        </Modal>
      )}
      {openReschedule && rescheduleAct && (
        <Modal title="Reabrir / Reagendar" onClose={() => { setOpenReschedule(false); setRescheduleAct(null); }}>
          <RescheduleForm
            loading={rescheduleMut.isPending}
            defaultLocalDT={nowLocalDT()}
            onSubmit={({ localDT, note }) => {
              const iso = toIsoFromLocalDT(localDT);
              if (!iso) {
                alert("Data/hora inválida.");
                return;
              }
              rescheduleMut.mutate({
                activityId: rescheduleAct.id,
                scheduled_for: iso,
                note: note || "",
              });
            }}
          />
        </Modal>
      )}
    </div>
    
  );
}

/** ===========================
 * Forms
 * =========================== */

function UploadForm({
  loading,
  onSubmit,
}: {
  loading: boolean;
  onSubmit: (payload: {
    deal: number;
    type: AttachmentType;
    version_label?: string;
    file: File;
  }) => void;
}) {
  const [type, setType] = useState<AttachmentType>("OUTRO");
  const [version, setVersion] = useState("");
  const [file, setFile] = useState<File | null>(null);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!file) return;
        onSubmit({ deal: 0, type, version_label: version || "", file });
      }}
      className="grid gap-3"
    >
      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Tipo</label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value as AttachmentType)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-600"
        >
          <option value="OUTRO">Outro</option>
          <option value="MEMORIAL">Memorial</option>
          <option value="CONTRATO">Contrato</option>
          <option value="PROPOSTA">Proposta</option>
        </select>
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Versão (opcional)</label>
        <input
          placeholder="Ex: v1, v2, revA..."
          value={version}
          onChange={(e) => setVersion(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Arquivo</label>
        <input
          type="file"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
        />
        <div className="text-[11px] text-slate-500">
          PDF, DOCX, imagens… (o backend salva em <b>media/deals/&lt;id&gt;/</b>)
        </div>
      </div>

      <button
        disabled={loading || !file}
        className="mt-1 w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 disabled:opacity-50 transition"
      >
        {loading ? "Enviando..." : "Enviar"}
      </button>
    </form>
  );
}

function ActivityForm({
  loading,
  onSubmit,
}: {
  loading: boolean;
  onSubmit: (payload: Partial<Activity>) => void;
}) {
  const [type, setType] = useState<ActivityType>("VISITA");

  // ✅ novo: modo compromisso
  const [isCommitment, setIsCommitment] = useState(false);

  const [occurredAt, setOccurredAt] = useState<string>(() => nowLocalDT());
  const [scheduledFor, setScheduledFor] = useState<string>(() => {
    // default: 2 horas pra frente
    const d = new Date();
    d.setHours(d.getHours() + 2);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
      d.getHours()
    )}:${pad(d.getMinutes())}`;
  });

  const [result, setResult] = useState("");
  const [notes, setNotes] = useState("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();

        if (isCommitment) {
          const iso = toIsoFromLocalDT(scheduledFor);
          if (!iso) {
            alert("Data/hora inválida.");
            return;
          }
          if (new Date(iso).getTime() < Date.now()) {
            alert("Compromisso precisa ser no futuro.");
            return;
          }
          onSubmit({
            type,
            status: "PENDING" as any,
            scheduled_for: iso,
            occurred_at: null,
            result: result || "",
            notes: notes || "",
          });
          return;
        }

        onSubmit({
          type,
          status: "DONE" as any,
          occurred_at: toIsoFromLocalDT(occurredAt),
          scheduled_for: null,
          result: result || "",
          notes: notes || "",
        });
      }}
      className="grid gap-3"
    >
      <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-3">
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={isCommitment}
            onChange={(e) => setIsCommitment(e.target.checked)}
          />
          <span className="font-semibold">Agendar como compromisso (data futura)</span>
        </label>
        <div className="text-xs opacity-70 mt-1">
          Se marcado, esta atividade entra em <b>Compromissos</b> e fica como{" "}
          <b>PENDENTE</b> até você concluir.
        </div>
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Tipo</label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value as ActivityType)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-600"
        >
          <option value="VISITA">Visita</option>
          <option value="LIGACAO">Ligação</option>
          <option value="WHATSAPP">WhatsApp</option>
          <option value="REUNIAO">Reunião</option>
          <option value="EMAIL">Email</option>
          <option value="TAREFA">Tarefa</option>
        </select>
      </div>

      {isCommitment ? (
        <div className="grid gap-1">
          <label className="text-xs text-slate-400">Agendar para</label>
          <input
            type="datetime-local"
            value={scheduledFor}
            onChange={(e) => setScheduledFor(e.target.value)}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
            required
          />
        </div>
      ) : (
        <div className="grid gap-1">
          <label className="text-xs text-slate-400">Data/Hora que aconteceu</label>
          <input
            type="datetime-local"
            value={occurredAt}
            onChange={(e) => setOccurredAt(e.target.value)}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          />
        </div>
      )}

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Resultado (curto)</label>
        <input
          placeholder="Ex: Cliente pediu proposta com permuta"
          value={result}
          onChange={(e) => setResult(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Observações</label>
        <textarea
          placeholder="Descreva como foi / detalhes / próximos passos..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={5}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <button
        disabled={loading}
        className="mt-1 w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 disabled:opacity-50 transition"
      >
        {loading ? "Salvando..." : isCommitment ? "Agendar" : "Registrar"}
      </button>
    </form>
  );
}

function ProposalForm({
  loading,
  projects,
  onSubmit,
}: {
  loading: boolean;
  projects: { id: number; name: string }[];
  onSubmit: (payload: Partial<Proposal> & { _file?: File | null }) => void;
}) {
  const [versionLabel, setVersionLabel] = useState("v1");
  const [status, setStatus] = useState<ProposalStatus>("DRAFT");

  const [valorTotal, setValorTotal] = useState("");
  const [valorEntrada, setValorEntrada] = useState("");

  const [temPermuta, setTemPermuta] = useState(false);
  const [permutaTipo, setPermutaTipo] = useState("PARCIAL");
  const [valorPermuta, setValorPermuta] = useState("");

  const [obraEntrega, setObraEntrega] = useState("");
  const [elevEntrega, setElevEntrega] = useState("");

  const [notes, setNotes] = useState("");

  const [selectedProjects, setSelectedProjects] = useState<number[]>([]);
  const [file, setFile] = useState<File | null>(null);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();

        onSubmit({
          version_label: versionLabel || "",
          status,

          valor_total: parseMoneyToNumberOrNull(valorTotal),
          valor_entrada: parseMoneyToNumberOrNull(valorEntrada),

          tem_permuta: temPermuta,
          permuta_tipo: temPermuta ? (permutaTipo || "") : "",
          valor_permuta: temPermuta ? parseMoneyToNumberOrNull(valorPermuta) : null,

          obra_entrega_prevista: obraEntrega || null,
          elevador_entrega_prevista: elevEntrega || null,

          notes: notes || "",
          projects: selectedProjects,

          _file: file,
        });
      }}
      className="grid gap-3"
    >
      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Versão</label>
        <input
          value={versionLabel}
          onChange={(e) => setVersionLabel(e.target.value)}
          placeholder="Ex: v1, v2, revA..."
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Status</label>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value as ProposalStatus)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-600"
        >
          <option value="DRAFT">Rascunho</option>
          <option value="SENT">Enviada</option>
          <option value="ACCEPTED">Aceita</option>
          <option value="REJECTED">Recusada</option>
        </select>
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-3">
        <div className="font-semibold">Empreendimentos</div>
        <div className="text-xs opacity-70 mb-2">
          Selecione 1 ou mais empreendimentos desta construtora.
        </div>

        {projects.length === 0 ? (
          <div className="text-sm opacity-70">
            Nenhum empreendimento cadastrado para esta construtora.
          </div>
        ) : (
          <div className="grid gap-2">
            {projects.map((p) => {
              const checked = selectedProjects.includes(p.id);
              return (
                <label key={p.id} className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={(e) => {
                      setSelectedProjects((prev) =>
                        e.target.checked
                          ? [...prev, p.id]
                          : prev.filter((x) => x !== p.id)
                      );
                    }}
                  />
                  <span>{p.name}</span>
                </label>
              );
            })}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="grid gap-1">
          <label className="text-xs text-slate-400">Valor total</label>
          <input
            value={valorTotal}
            onChange={(e) => setValorTotal(e.target.value)}
            placeholder="Ex: 250000 ou 250000,50"
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          />
        </div>

        <div className="grid gap-1">
          <label className="text-xs text-slate-400">Entrada</label>
          <input
            value={valorEntrada}
            onChange={(e) => setValorEntrada(e.target.value)}
            placeholder="Ex: 50000"
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          />
        </div>
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-950/40 p-3">
        <div className="flex items-center gap-2">
          <input
            id="permuta"
            type="checkbox"
            checked={temPermuta}
            onChange={(e) => setTemPermuta(e.target.checked)}
          />
          <label htmlFor="permuta" className="font-semibold">
            Tem permuta?
          </label>
        </div>

        {temPermuta && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
            <div className="grid gap-1">
              <label className="text-xs text-slate-400">Tipo</label>
              <select
                value={permutaTipo}
                onChange={(e) => setPermutaTipo(e.target.value)}
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-600"
              >
                <option value="PARCIAL">Parcial</option>
                <option value="TOTAL">Total</option>
              </select>
            </div>

            <div className="grid gap-1">
              <label className="text-xs text-slate-400">
                Valor estimado da permuta
              </label>
              <input
                value={valorPermuta}
                onChange={(e) => setValorPermuta(e.target.value)}
                placeholder="Ex: 120000"
                className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
              />
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="grid gap-1">
          <label className="text-xs text-slate-400">Entrega da obra (opcional)</label>
          <input
            type="date"
            value={obraEntrega}
            onChange={(e) => setObraEntrega(e.target.value)}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          />
        </div>

        <div className="grid gap-1">
          <label className="text-xs text-slate-400">
            Entrega dos elevadores (opcional)
          </label>
          <input
            type="date"
            value={elevEntrega}
            onChange={(e) => setElevEntrega(e.target.value)}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          />
        </div>
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Arquivo da proposta (opcional)</label>
        <input
          type="file"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"
        />
        <div className="text-[11px] text-slate-500">
          Se enviar aqui, o sistema cria a proposta e já anexa como <b>PROPOSTA</b>.
        </div>
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Observações</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={5}
          placeholder="Condições, escopo, prazos, observações..."
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <button
        disabled={loading}
        className="mt-1 w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 disabled:opacity-50 transition"
      >
        {loading ? "Salvando..." : "Registrar proposta"}
      </button>
    </form>
  );
}

/** ===========================
 * Reschedule
 * =========================== */

function RescheduleForm({
  loading,
  defaultLocalDT,
  onSubmit,
}: {
  loading: boolean;
  defaultLocalDT: string;
  onSubmit: (payload: { localDT: string; note: string }) => void;
}) {
  const [localDT, setLocalDT] = useState(defaultLocalDT);
  const [note, setNote] = useState("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit({ localDT, note });
      }}
      className="grid gap-3"
    >
      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Nova data/hora</label>
        <input
          type="datetime-local"
          value={localDT}
          onChange={(e) => setLocalDT(e.target.value)}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
          required
        />
      </div>

      <div className="grid gap-1">
        <label className="text-xs text-slate-400">Comentário (opcional)</label>
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          rows={4}
          placeholder="Ex: cliente pediu para reagendar / não atendeu / remarcado..."
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 outline-none focus:ring-2 focus:ring-slate-600"
        />
      </div>

      <button
        disabled={loading}
        className="mt-1 w-full rounded-lg bg-slate-100 text-slate-900 font-semibold py-2 hover:opacity-90 disabled:opacity-50 transition"
      >
        {loading ? "Salvando..." : "Reabrir e reagendar"}
      </button>
    </form>
  );
}

/** ===========================
 * Modal
 * =========================== */

function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div
      onClick={onClose}
      className="fixed inset-0 bg-black/60 grid place-items-center p-4 z-50"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-2xl"
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="font-extrabold">{title}</div>
          <button
            onClick={onClose}
            className="ml-auto rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm hover:bg-slate-800 transition"
          >
            Fechar
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}